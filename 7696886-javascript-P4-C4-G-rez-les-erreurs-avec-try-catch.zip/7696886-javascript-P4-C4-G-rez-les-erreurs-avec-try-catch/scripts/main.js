/*********************************************************************************
 * 
 * Point d'entrée, c'est lui qui intialise le jeu et lance la boucle de jeu. 
 * 
 *********************************************************************************/

lancerJeu()

// J'ai mis ce code en commentaire, nous pourrons le récupérer lorsque nous en auront besoin :

// let inputEcriture = document.getElementById("inputEcriture")
// console.log(inputEcriture)

// let btnValiderMot = document.getElementById("btnValiderMot")
// console.log(btnValiderMot)

// let zoneProposition = document.querySelector(".zoneProposition")
// console.log(zoneProposition)

// let spanScore = document.querySelector(".zoneScore span")
// console.log(spanScore)

// let listeBtnRadio = document.querySelectorAll(".optionSource input")
// console.log(listeBtnRadio)